import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import IsolationForest
from sklearn.decomposition import PCA

# For visualizing data
import matplotlib.pyplot as plt
import seaborn as sns
# Generating synthetic data
np.random.seed(42)
n_samples = 1000
n_outliers = 50

# Generate normal distributed data
X_normal = 0.3 * np.random.randn(n_samples, 2)
X_normal = np.r_[X_normal + 2, X_normal - 2]

# Generate outliers
X_outliers = np.random.uniform(low=-4, high=4, size=(n_outliers, 2))

# Combine the dataset
X = np.r_[X_normal, X_outliers]
# Introduce missing values into the dataset
X[np.random.choice(X.shape[0], 10), np.random.choice(X.shape[1], 1)] = np.nan

# Handling missing values
imputer = SimpleImputer(strategy='mean')
X_imputed = imputer.fit_transform(X)
# Feature Scaling using StandardScaler
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_imputed)
# Applying PCA to reduce dimensionality for visualization
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)
# Applying Isolation Forest for anomaly detection
model = IsolationForest(contamination=0.05, random_state=42)
model.fit(X_pca)
anomalies = model.predict(X_pca)

# Converting -1 to 1 (anomaly) and 1 to 0 (normal)
anomalies = np.where(anomalies == -1, 1, 0)
# Visualizing the anomalies
plt.figure(figsize=(10, 6))
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=anomalies, cmap='coolwarm')
plt.title('Anomaly Detection using Isolation Forest')
plt.xlabel('PCA Component 1')
plt.ylabel('PCA Component 2')
plt.show()
