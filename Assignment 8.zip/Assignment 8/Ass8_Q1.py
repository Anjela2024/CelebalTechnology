import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score

df = pd.read_csv('Loan.csv')

print(df.head())
print(df.columns)

print(df.isnull().sum())

if len(df.columns) > 2:
    
    df.drop('Loan_ID', axis=1, inplace=True)
    df['Loan_Status'] = df['Loan_Status'].map({'Y': 1, 'N': 0})
    label_encoder = LabelEncoder()
    
    
    for column in df.select_dtypes(include='object').columns:
        df[column] = label_encoder.fit_transform(df[column])


    numerical_columns = df.select_dtypes(include=['int64', 'float64']).columns.difference(['Loan_Status'])
    
    if len(numerical_columns) > 0:
        scaler = StandardScaler()
        df[numerical_columns] = scaler.fit_transform(df[numerical_columns])
    
    
    X = df.drop('Loan_Status', axis=1)  # Features
    y = df['Loan_Status']  # Target variable

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Model Training and Evaluation
    model = RandomForestClassifier(random_state=42)
    model.fit(X_train, y_train)

    # Predict on the test set
    y_pred = model.predict(X_test)

    # Evaluate the model
    print(classification_report(y_test, y_pred))
    print("Accuracy:", accuracy_score(y_test, y_pred))
else:
    print("Insufficient data: The dataset only has 'Loan_ID' and 'Loan_Status'. Cannot proceed with model training.")
