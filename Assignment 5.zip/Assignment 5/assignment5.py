import pandas as pd
import numpy as np

# Load the Titanic dataset
data = pd.read_csv('titanic.csv')

# Display the first few rows of the dataset before preprocessing
print(data.head())

# Data Cleaning: Dropping columns that are not useful for predictive modeling
data.drop(['PassengerId', 'Name', 'Ticket'], axis=1, inplace=True)

# Handling Missing Values
# Filling missing values in 'Age' with median age
data['Age'].fillna(data['Age'].median(), inplace=True)

# Creating a new feature 'HasCabin' and filling missing 'Cabin' with '0'
data['HasCabin'] = data['Cabin'].notna().astype(int)
data.drop('Cabin', axis=1, inplace=True)

# Filling missing values in 'Embarked' with the most common value
data['Embarked'].fillna(data['Embarked'].mode()[0], inplace=True)

# Transformation: Applying log transformation to 'Fare' to reduce skewness
data['Fare'] = data['Fare'].apply(lambda x: np.log(x + 1))

# Normalization: Standardizing numerical features manually
# Mean and standard deviation calculation
mean_age = data['Age'].mean()
std_age = data['Age'].std()
mean_fare = data['Fare'].mean()
std_fare = data['Fare'].std()

# Standardizing 'Age' and 'Fare'
data['Age'] = (data['Age'] - mean_age) / std_age
data['Fare'] = (data['Fare'] - mean_fare) / std_fare

# Encoding Categorical Variables
# Label encoding for 'Sex'
data['Sex'] = data['Sex'].map({'male': 1, 'female': 0})

# One-hot encoding for 'Embarked'
embarked_dummies = pd.get_dummies(data['Embarked'], prefix='Embarked', drop_first=True)
data = pd.concat([data, embarked_dummies], axis=1)
data.drop('Embarked', axis=1, inplace=True)

# Feature Engineering
# Creating new feature 'FamilySize'
data['FamilySize'] = data['SibSp'] + data['Parch'] + 1

# Creating new feature 'IsAlone'
data['IsAlone'] = (data['FamilySize'] == 1).astype(int)

# Display the first few rows of the processed dataset
print(data.head())
