import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.base import BaseEstimator, TransformerMixin

class FeatureEngineering(BaseEstimator, TransformerMixin):
    def __init__(self):
        pass
    
    def fit(self, X, y=None):
        return self
    
    def transform(self, X, y=None):
        X = X.copy()
        
        # Example: Creating new features
        if 'Pclass' in X.columns and 'Age' in X.columns:
            X['new_feature'] = X['Pclass'] * X['Age']  # Interaction feature example
        if 'Fare' in X.columns:
            X['log_fare'] = np.log1p(X['Fare'])  # Log transformation example
        
        return X

# Load the Titanic dataset
df = pd.read_csv('titanic.csv')

# Print the columns to verify the correct target column name
print(df.columns)

# Update the target column name based on the output above
# Assuming 'Survived' is the correct column, but replace it if necessary
if 'Survived' not in df.columns:
    raise ValueError("The expected target column 'Survived' is not present in the dataset.")

X = df.drop('Survived', axis=1)
y = df['Survived']

# Identify numerical and categorical columns
numerical_cols = X.select_dtypes(include=['int64', 'float64']).columns
categorical_cols = X.select_dtypes(include=['object']).columns

# Numerical data pipeline
numerical_pipeline = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

# Categorical data pipeline
categorical_pipeline = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

# Combine preprocessing steps
preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_pipeline, numerical_cols),
        ('cat', categorical_pipeline, categorical_cols)
    ])

# Full pipeline with feature engineering and preprocessing
full_pipeline = Pipeline(steps=[
    ('feature_engineering', FeatureEngineering()),
    ('preprocessor', preprocessor)
])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Fit the pipeline on the training data
X_train_preprocessed = full_pipeline.fit_transform(X_train)

# Transform the test data
X_test_preprocessed = full_pipeline.transform(X_test)

print("Training Features Shape:", X_train_preprocessed.shape)
print("Testing Features Shape:", X_test_preprocessed.shape)
