import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler


data = pd.read_csv("titanic.csv")

print(data.head())  # First few rows
print(data.shape)  # Number of rows and columns
print(data.info())  # Data types
print(data.describe())  # Summary statistics


data.fillna(method='ffill', inplace=True) 


data['FamilySize'] = data['SibSp'] + data['Parch'] + 1  
data['IsAlone'] = 1 
data.loc[data['FamilySize'] > 1, 'IsAlone'] = 0  

le = LabelEncoder()
data['Sex'] = le.fit_transform(data['Sex'])
data['Embarked'] = le.fit_transform(data['Embarked'])

scaler = StandardScaler()
data[['Age', 'Fare']] = scaler.fit_transform(data[['Age', 'Fare']])


data = pd.get_dummies(data, columns=['Embarked'])

print(data.head())
