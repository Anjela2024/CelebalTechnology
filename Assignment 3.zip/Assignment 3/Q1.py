import matplotlib.pyplot as plt
import pandas as pd

# Load the Iris dataset
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
column_names = ['sepal_length', 'sepal_width', 'petal_length', 'petal_width', 'species']
iris = pd.read_csv(url, header=None, names=column_names)

# Display the first few rows of the dataset
print(iris.head())

# Scatter plot for Sepal length vs Sepal width
plt.figure(figsize=(10, 6))
for species, color in zip(iris['species'].unique(), ['red', 'green', 'blue']):
    subset = iris[iris['species'] == species]
    plt.scatter(subset['sepal_length'], subset['sepal_width'], label=species, color=color)
plt.xlabel('Sepal Length')
plt.ylabel('Sepal Width')
plt.title('Sepal Length vs Sepal Width')
plt.legend()
plt.show()

# Scatter plot for Petal length vs Petal width
plt.figure(figsize=(10, 6))
for species, color in zip(iris['species'].unique(), ['red', 'green', 'blue']):
    subset = iris[iris['species'] == species]
    plt.scatter(subset['petal_length'], subset['petal_width'], label=species, color=color)
plt.xlabel('Petal Length')
plt.ylabel('Petal Width')
plt.title('Petal Length vs Petal Width')
plt.legend()
plt.show()

# Pair plot to visualize pairwise relationships in the dataset
pd.plotting.scatter_matrix(iris, figsize=(15, 15), diagonal='hist', marker='o', c=[['red', 'green', 'blue'][['setosa', 'versicolor', 'virginica'].index(species)] for species in iris['species']])
plt.suptitle('Scatter Matrix of Iris Features')
plt.show()

# Histograms for each feature
iris.hist(bins=20, figsize=(10, 8), color='purple')
plt.suptitle('Distribution of Features')
plt.show()
