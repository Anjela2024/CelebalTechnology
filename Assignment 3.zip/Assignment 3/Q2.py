import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Creating a sample fruits dataset
data = {
    'Fruit': ['Apple', 'Orange', 'Banana', 'Apple', 'Orange', 'Banana', 'Apple', 'Orange', 'Banana', 'Apple'],
    'Color': ['Red', 'Orange', 'Yellow', 'Green', 'Orange', 'Yellow', 'Red', 'Orange', 'Green', 'Green'],
    'Weight': [150, 120, 110, 140, 130, 100, 160, 125, 105, 145],
    'Price': [10, 12, 8, 9, 13, 7, 11, 12, 9, 10]
}

df = pd.DataFrame(data)

# 1. Display the dataset
print(df)

# 2. Find the shape (number of rows and columns)
shape = df.shape
print(f"Shape of the dataset: {shape}")

# 3. Check for any null values
null_values = df.isnull().sum()
print("Null values in each column:\n", null_values)

# 4. Find the data types of each column
data_types = df.dtypes
print("Data types of each column:\n", data_types)

# 5. Find the statistical information for each numerical column
stats = df.describe()
print("Statistical information for numerical columns:\n", stats)

# 6. Convert any categorical columns to numerical columns
df_encoded = df.copy()
df_encoded['Fruit'] = df_encoded['Fruit'].astype('category').cat.codes
df_encoded['Color'] = df_encoded['Color'].astype('category').cat.codes
print("Encoded dataset:\n", df_encoded)

# 7. Find the correlation matrix
correlation_matrix = df_encoded.corr()
print("Correlation matrix:\n", correlation_matrix)

# 8. Perform data visualization using matplotlib
# Plotting the correlation matrix
plt.figure(figsize=(8, 6))
plt.imshow(correlation_matrix, cmap='coolwarm', interpolation='none', aspect='auto')
plt.colorbar()
plt.xticks(range(len(correlation_matrix)), correlation_matrix.columns, rotation=45)
plt.yticks(range(len(correlation_matrix)), correlation_matrix.index)
plt.title('Correlation Matrix')
plt.show()

# Plotting histograms for numerical columns
df[['Weight', 'Price']].hist(bins=10, figsize=(10, 5))
plt.tight_layout()
plt.show()

# Scatter plot of Weight vs. Price colored by Fruit
colors = {'Apple': 'red', 'Orange': 'orange', 'Banana': 'yellow'}
plt.figure(figsize=(8, 6))
plt.scatter(df['Weight'], df['Price'], c=df['Fruit'].apply(lambda x: colors[x]), s=100)
for fruit in colors:
    plt.scatter([], [], c=colors[fruit], label=fruit)
plt.title('Scatter plot of Weight vs. Price')
plt.xlabel('Weight (grams)')
plt.ylabel('Price ($)')
plt.legend()
plt.show()
